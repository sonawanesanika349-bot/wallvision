# WallVision — Smart Wall Paint Visualizer

A full-stack project using:

- Frontend: React + Vite
- Backend: Flask + Python
- Image processing: OpenCV + NumPy
- Database: PostgreSQL
- Authentication: JWT
- No paid APIs

## Features

- User registration and login
- Upload a room image
- Automatic wall-area estimation with OpenCV
- Select paint colors
- Apply a realistic color overlay to the detected wall region
- Before/after preview
- Dominant room color detection
- Smart complementary color recommendations
- Save visualizations to PostgreSQL
- View saved designs
- Delete saved designs
- Responsive colorful UI

## Project structure

```text
wallvision/
├── backend/
│   ├── app.py
│   ├── config.py
│   ├── db.py
│   ├── auth.py
│   ├── image_processing.py
│   ├── requirements.txt
│   ├── .env.example
│   └── uploads/
└── frontend/
    ├── package.json
    ├── vite.config.js
    ├── index.html
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── api.js
        ├── styles.css
        └── components/
```

## 1. PostgreSQL setup

Create a database:

```sql
CREATE DATABASE wallvision;
```

The Flask backend automatically creates the required tables.

## 2. Backend setup

Open a terminal:

```bash
cd backend
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

macOS/Linux:

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and edit the PostgreSQL values.

Start Flask:

```bash
python app.py
```

Backend runs at:

```text
http://localhost:5000
```

## 3. Frontend setup

Open another terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at the URL shown by Vite, normally:

```text
http://localhost:5173
```

## OpenCV wall detection

The project uses OpenCV to estimate likely wall pixels from the uploaded image. It combines:

- image resizing
- HSV/Lab color analysis
- edge detection
- connected-component filtering
- morphological cleanup

This is intentionally API-free and suitable as a college/project prototype. For production-grade architectural wall segmentation, a trained segmentation model can later replace `detect_wall_mask()` without changing the frontend.

## API endpoints

### Authentication

`POST /api/auth/register`

`POST /api/auth/login`

### Image processing

`POST /api/visualize`

Multipart fields:

- `image`
- `color`
- `color_name`

### Saved designs

`GET /api/designs`

`POST /api/designs`

`DELETE /api/designs/<id>`

### Health

`GET /api/health`

## Notes

The generated visualization images are stored under `backend/uploads/`. In production, use object storage and a production WSGI server.
