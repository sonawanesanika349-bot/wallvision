const API_BASE = "http://localhost:5000/api";

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, options);
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || "Something went wrong");
  }

  return data;
}

export function register(payload) {
  return request("/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
}

export function login(payload) {
  return request("/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
}

export function visualize(file, color, colorName, token) {
  const form = new FormData();
  form.append("image", file);
  form.append("color", color);
  form.append("color_name", colorName);

  return request("/visualize", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: form
  });
}

export function saveDesign(data, token) {
  return request("/designs", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(data)
  });
}

export function getDesigns(token) {
  return request("/designs", {
    headers: { Authorization: `Bearer ${token}` }
  });
}

export function deleteDesign(id, token) {
  return request(`/designs/${id}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` }
  });
}

export { API_BASE };
