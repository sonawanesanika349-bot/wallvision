import { useState } from "react";
import { Palette, Sparkles, LogIn, LogOut, ArrowRight, CheckCircle2 } from "lucide-react";
import AuthModal from "./components/AuthModal";
import Visualizer from "./components/Visualizer";
import Designs from "./components/Designs";

function App() {
  const [auth, setAuth] = useState(null);
  const [modal, setModal] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);

  function onAuth(data) {
    setAuth(data);
    localStorage.setItem("wallvision_token", data.token);
    localStorage.setItem("wallvision_user", JSON.stringify(data.user));
  }

  function logout() {
    setAuth(null);
    localStorage.removeItem("wallvision_token");
    localStorage.removeItem("wallvision_user");
  }

  // Restore a previous login.
  useState(() => {
    const token = localStorage.getItem("wallvision_token");
    const user = localStorage.getItem("wallvision_user");
    if (token && user) setAuth({ token, user: JSON.parse(user) });
  });

  return (
    <div className="app">
      <header className="navbar">
        <a className="brand" href="#home">
          <span className="brand-mark"><Palette size={21}/></span>
          <span>Wall<span>Vision</span></span>
        </a>

        <nav>
          <a href="#home">Home</a>
          <a href="#how">How it works</a>
          <a href="#visualizer">Visualizer</a>
          {auth && <a href="#saved">My designs</a>}
        </nav>

        <div className="nav-actions">
          {auth ? (
            <>
              <span className="welcome">Hi, {auth.user.name.split(" ")[0]}</span>
              <button className="outline-btn" onClick={logout}><LogOut size={17}/> Logout</button>
            </>
          ) : (
            <>
              <button className="text-btn" onClick={() => setModal("login")}>Login</button>
              <button className="nav-cta" onClick={() => setModal("register")}>Get started <ArrowRight size={16}/></button>
            </>
          )}
        </div>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <div className="hero-badge"><Sparkles size={16}/> AI-assisted wall visualization</div>
            <h1>Turn your room into your <span>favorite color.</span></h1>
            <p>
              Upload a room photo, experiment with beautiful paint shades,
              and preview your wall before opening a paint can.
            </p>

            <div className="hero-actions">
              <a href="#visualizer" className="primary-btn large">Start visualizing <ArrowRight size={19}/></a>
              {!auth && <button className="secondary-btn large" onClick={() => setModal("register")}>Create free account</button>}
            </div>

            <div className="trust-row">
              <span><CheckCircle2 size={17}/> OpenCV powered</span>
              <span><CheckCircle2 size={17}/> PostgreSQL saved designs</span>
              <span><CheckCircle2 size={17}/> No paid APIs</span>
            </div>
          </div>

          <div className="hero-art">
            <div className="room-card">
              <div className="room-window" />
              <div className="room-wall" />
              <div className="room-sofa" />
              <div className="room-table" />
              <div className="floating-card">
                <div className="mini-swatch" />
                <div>
                  <small>Recommended</small>
                  <strong>Lavender Mist</strong>
                </div>
              </div>
            </div>
            <div className="paint-dots">
              <i/><i/><i/><i/><i/>
            </div>
          </div>
        </section>

        <section className="stats-strip">
          <div><strong>12+</strong><span>Curated paint shades</span></div>
          <div><strong>2</strong><span>Before / after views</span></div>
          <div><strong>100%</strong><span>Browser-based workflow</span></div>
          <div><strong>∞</strong><span>Design experiments</span></div>
        </section>

        <section className="how-section" id="how">
          <div className="section-heading">
            <span className="eyebrow">HOW IT WORKS</span>
            <h2>From photo to <span>fresh walls.</span></h2>
          </div>

          <div className="steps">
            <div className="step">
              <b>01</b>
              <h3>Upload</h3>
              <p>Choose a clear room image from your computer.</p>
            </div>
            <div className="step">
              <b>02</b>
              <h3>Pick a color</h3>
              <p>Explore the colorful paint palette and choose a shade.</p>
            </div>
            <div className="step">
              <b>03</b>
              <h3>Visualize</h3>
              <p>Flask sends the image to OpenCV for wall-area estimation.</p>
            </div>
            <div className="step">
              <b>04</b>
              <h3>Save</h3>
              <p>Keep your favorite results in your PostgreSQL account.</p>
            </div>
          </div>
        </section>

        <Visualizer
          token={auth?.token}
          onSaved={() => setRefreshKey((v) => v + 1)}
        />

        <Designs token={auth?.token} refreshKey={refreshKey} />
      </main>

      <footer>
        <div className="footer-brand"><Palette size={20}/> WallVision</div>
        <p>Smart wall paint visualization with React, Flask, OpenCV & PostgreSQL.</p>
      </footer>

      {modal && (
        <AuthModal
          mode={modal}
          onClose={() => setModal(null)}
          onSuccess={onAuth}
        />
      )}
    </div>
  );
}

export default App;
