import { useMemo, useState } from "react";
import { ImagePlus, Sparkles, Save, Download, RotateCcw } from "lucide-react";
import { visualize, saveDesign } from "../api";

const COLORS = [
  { name: "Lavender", hex: "#C8A2C8" },
  { name: "Mint Green", hex: "#B8D8BA" },
  { name: "Sky Blue", hex: "#A7C7E7" },
  { name: "Peach", hex: "#FFB07C" },
  { name: "Rose Pink", hex: "#E5989B" },
  { name: "Cream", hex: "#F5E6CA" },
  { name: "Warm Beige", hex: "#DCC7A1" },
  { name: "Modern Gray", hex: "#8D99AE" },
  { name: "Deep Teal", hex: "#264653" },
  { name: "Olive", hex: "#7A8450" },
  { name: "Pure White", hex: "#FFFFFF" },
  { name: "Charcoal", hex: "#343A40" }
];

export default function Visualizer({ token, onSaved }) {
  const [file, setFile] = useState(null);
  const [localPreview, setLocalPreview] = useState("");
  const [selected, setSelected] = useState(COLORS[0]);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const canProcess = Boolean(file && token);

  const recommendation = useMemo(() => {
    if (!result) return null;
    const percent = result.wall_percentage;
    if (percent >= 35) return "Great wall coverage detected";
    if (percent >= 15) return "Good wall area detected";
    return "Try a brighter, clearer room photo";
  }, [result]);

  function chooseFile(e) {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (selectedFile.size > 10 * 1024 * 1024) {
      setError("Please choose an image smaller than 10 MB.");
      return;
    }

    setError("");
    setFile(selectedFile);
    setResult(null);
    setLocalPreview(URL.createObjectURL(selectedFile));
  }

  async function runVisualizer() {
    if (!canProcess) {
      setError(token ? "Please upload an image first." : "Please login first.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const data = await visualize(file, selected.hex, selected.name, token);
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function saveCurrent() {
    if (!result) return;

    setSaving(true);
    try {
      await saveDesign(result, token);
      onSaved?.();
      alert("Design saved successfully.");
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  function reset() {
    setFile(null);
    setResult(null);
    setLocalPreview("");
    setError("");
  }

  function downloadResult() {
    if (!result) return;
    const link = document.createElement("a");
    link.href = `http://localhost:5000${result.result_image}`;
    link.download = `wallvision-${selected.name.toLowerCase().replaceAll(" ", "-")}.jpg`;
    link.target = "_blank";
    link.click();
  }

  return (
    <section className="visualizer-section" id="visualizer">
      <div className="section-heading">
        <span className="eyebrow">AI-ASSISTED VISUALIZER</span>
        <h2>See your room in a <span>new color.</span></h2>
        <p>Upload a room photo, choose a paint shade, and let OpenCV estimate the wall area.</p>
      </div>

      <div className="workspace">
        <div className="workspace-top">
          <div>
            <h3>1. Upload your room</h3>
            <p className="muted">Use a clear photo where the wall is visible.</p>
          </div>

          <label className="upload-btn">
            <ImagePlus size={19}/>
            {file ? "Change image" : "Upload image"}
            <input type="file" accept="image/png,image/jpeg,image/webp" onChange={chooseFile} hidden />
          </label>
        </div>

        <div className="preview-grid">
          <div className="image-card">
            <div className="card-label">ORIGINAL</div>
            <div className="image-frame">
              {localPreview ? (
                <img src={localPreview} alt="Original room" />
              ) : (
                <div className="empty-preview">
                  <ImagePlus size={42}/>
                  <span>Your room photo appears here</span>
                </div>
              )}
            </div>
          </div>

          <div className="image-card">
            <div className="card-label">VISUALIZED</div>
            <div className="image-frame result-frame">
              {result ? (
                <img src={`http://localhost:5000${result.result_image}`} alt="Paint visualization" />
              ) : (
                <div className="empty-preview">
                  <Sparkles size={42}/>
                  <span>Choose a color and visualize</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="controls">
          <div>
            <h3>2. Pick a paint color</h3>
            <div className="color-grid">
              {COLORS.map((color) => (
                <button
                  key={color.hex}
                  className={`color-option ${selected.hex === color.hex ? "active" : ""}`}
                  onClick={() => setSelected(color)}
                  title={color.name}
                >
                  <span style={{ background: color.hex }} />
                  <small>{color.name}</small>
                </button>
              ))}
            </div>
          </div>

          <div className="selected-color">
            <div className="selected-swatch" style={{ background: selected.hex }} />
            <div>
              <span className="muted">Selected paint</span>
              <strong>{selected.name}</strong>
              <code>{selected.hex}</code>
            </div>
          </div>
        </div>

        {error && <div className="error-box">{error}</div>}

        <div className="action-row">
          <button className="secondary-btn" onClick={reset}>
            <RotateCcw size={18}/> Reset
          </button>

          <button className="primary-btn large" onClick={runVisualizer} disabled={loading}>
            <Sparkles size={19}/>
            {loading ? "Processing with OpenCV..." : "Visualize Wall"}
          </button>

          {result && (
            <>
              <button className="secondary-btn" onClick={downloadResult}>
                <Download size={18}/> Download
              </button>
              <button className="secondary-btn" onClick={saveCurrent} disabled={saving}>
                <Save size={18}/> {saving ? "Saving..." : "Save Design"}
              </button>
            </>
          )}
        </div>

        {result && (
          <div className="analysis-result">
            <div>
              <span>Detected room tone</span>
              <strong>{result.detected_color}</strong>
            </div>
            <div>
              <span>Estimated wall area</span>
              <strong>{result.wall_percentage}%</strong>
            </div>
            <div>
              <span>Recommendation</span>
              <strong>{recommendation}</strong>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
