import { useState } from "react";
import { X, Palette, UserPlus, LogIn } from "lucide-react";
import { login, register } from "../api";

export default function AuthModal({ mode, onClose, onSuccess }) {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [isRegister, setIsRegister] = useState(mode === "register");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const result = isRegister ? await register(form) : await login(form);
      onSuccess(result);
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
        <button className="close-btn" onClick={onClose}><X /></button>
        <div className="modal-icon"><Palette /></div>
        <h2>{isRegister ? "Create your account" : "Welcome back"}</h2>
        <p className="muted">
          {isRegister
            ? "Save your favorite wall designs."
            : "Continue designing your dream room."}
        </p>

        {error && <div className="error-box">{error}</div>}

        <form onSubmit={submit} className="form">
          {isRegister && (
            <input
              required
              placeholder="Full name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          )}

          <input
            required
            type="email"
            placeholder="Email address"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />

          <input
            required
            minLength={6}
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />

          <button className="primary-btn" disabled={loading}>
            {loading ? "Please wait..." : isRegister ? <><UserPlus size={18}/> Create account</> : <><LogIn size={18}/> Login</>}
          </button>
        </form>

        <button className="switch-auth" onClick={() => setIsRegister(!isRegister)}>
          {isRegister ? "Already have an account? Login" : "New here? Create an account"}
        </button>
      </div>
    </div>
  );
}
