import { useEffect, useState } from "react";
import { Trash2, ExternalLink, Clock3 } from "lucide-react";
import { deleteDesign, getDesigns } from "../api";

export default function Designs({ token, refreshKey }) {
  const [designs, setDesigns] = useState([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    if (!token) return;
    setLoading(true);
    try {
      setDesigns(await getDesigns(token));
    } catch {
      setDesigns([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [token, refreshKey]);

  async function remove(id) {
    if (!confirm("Delete this saved design?")) return;
    await deleteDesign(id, token);
    setDesigns((items) => items.filter((item) => item.id !== id));
  }

  if (!token) {
    return (
      <section className="saved-section" id="saved">
        <div className="login-prompt">
          <h2>Save your favorite designs.</h2>
          <p>Login to keep your visualizations in PostgreSQL and access them later.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="saved-section" id="saved">
      <div className="section-heading compact">
        <span className="eyebrow">YOUR COLLECTION</span>
        <h2>Saved <span>designs.</span></h2>
      </div>

      {loading ? (
        <div className="loading-text">Loading designs...</div>
      ) : designs.length === 0 ? (
        <div className="empty-saved">
          <h3>No saved designs yet</h3>
          <p>Visualize a wall above and save it to build your collection.</p>
        </div>
      ) : (
        <div className="design-grid">
          {designs.map((design) => (
            <article className="design-card" key={design.id}>
              <div className="design-images">
                <img src={`http://localhost:5000${design.original_image}`} alt="Original" />
                <img src={`http://localhost:5000${design.result_image}`} alt="Visualization" />
              </div>
              <div className="design-info">
                <div>
                  <strong>{design.color_name}</strong>
                  <span className="color-code">
                    <i style={{ background: design.color_hex }} />
                    {design.color_hex}
                  </span>
                </div>
                <span className="date">
                  <Clock3 size={14}/>
                  {new Date(design.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="design-actions">
                <a href={`http://localhost:5000${design.result_image}`} target="_blank" rel="noreferrer">
                  <ExternalLink size={16}/> Open
                </a>
                <button onClick={() => remove(design.id)}>
                  <Trash2 size={16}/> Delete
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
